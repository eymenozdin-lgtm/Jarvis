JARVIS ANDROID - KURULUM
1) Bilgisayarda Android Studio'yu aç: File > Open > bu "jarvis-android" klasörü. Sync bitsin.
2) Build > Build Bundle(s) / APK(s) > Build APK(s). APK'yı telefonlara kur (iki telefona da).
3) Kontrol EDİLECEK telefonda:
   Ayarlar > Erişilebilirlik > İndirilen uygulamalar > Jarvis Uzaktan Kontrol > Aç.
   (Android 13+ ise önce: Ayarlar > Uygulamalar > Jarvis > ⋮ > "Kısıtlanmış ayarlara izin ver".)
4) İki telefonda Jarvis > Eşleştir ile kodları değiş tokuş et.
5) Kumanda telefonda Kontrol > Dokunmatik yüzeyi aç > "Ekranı göster".
Sadece kendi telefonlarını eşleştir.
