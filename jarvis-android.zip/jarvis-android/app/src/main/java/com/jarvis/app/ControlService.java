package com.jarvis.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Base64;
import android.view.Display;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.io.ByteArrayOutputStream;

public class ControlService extends AccessibilityService {
    static volatile ControlService inst;
    interface Shot { void done(String b64, int w, int h); }

    @Override protected void onServiceConnected() { inst = this; }
    @Override public boolean onUnbind(Intent i) { inst = null; return super.onUnbind(i); }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
    @Override public void onInterrupt() {}

    private Rect screen() { return getSystemService(WindowManager.class).getMaximumWindowMetrics().getBounds(); }

    // x,y değerleri 0..1 arası (ekranın oranı)
    void swipe(float x1, float y1, float x2, float y2, long ms) {
        Rect r = screen();
        Path p = new Path();
        p.moveTo(x1 * r.width(), y1 * r.height());
        if (Math.abs(x1 - x2) + Math.abs(y1 - y2) > 0.002f) p.lineTo(x2 * r.width(), y2 * r.height());
        dispatchGesture(new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, Math.max(ms, 1))).build(), null, null);
    }
    void tap(float x, float y) { swipe(x, y, x, y, 60); }
    void longPress(float x, float y) { swipe(x, y, x, y, 700); }

    void global(String k) {
        int a = k.equals("back") ? GLOBAL_ACTION_BACK : k.equals("home") ? GLOBAL_ACTION_HOME
              : k.equals("recents") ? GLOBAL_ACTION_RECENTS : GLOBAL_ACTION_NOTIFICATIONS;
        performGlobalAction(a);
    }

    private AccessibilityNodeInfo focused() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        return root == null ? null : root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
    }
    private void setText(AccessibilityNodeInfo n, String s) {
        Bundle b = new Bundle();
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, s);
        n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b);
    }
    private String current(AccessibilityNodeInfo n) {
        CharSequence t = n.getText();
        return (t == null || n.isShowingHintText()) ? "" : t.toString();
    }
    void text(String s) {
        AccessibilityNodeInfo n = focused();
        if (n != null) setText(n, current(n) + s);
    }
    void key(String k) {
        AccessibilityNodeInfo n = focused();
        if (n == null) return;
        if (k.equals("back")) {
            String c = current(n);
            if (!c.isEmpty()) setText(n, c.substring(0, c.length() - 1));
        } else if (k.equals("enter")) {
            n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId());
        }
    }

    // Ekran görüntüsü (Android 11+). Genişlik 480 px, JPEG %45.
    void shot(Shot cb) {
        takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
            @Override public void onSuccess(ScreenshotResult r) {
                try {
                    Bitmap hw = Bitmap.wrapHardwareBuffer(r.getHardwareBuffer(), r.getColorSpace());
                    Bitmap b = hw.copy(Bitmap.Config.ARGB_8888, false);
                    r.getHardwareBuffer().close();
                    int w = 480, h = Math.round(480f * b.getHeight() / b.getWidth());
                    Bitmap s = Bitmap.createScaledBitmap(b, w, h, true);
                    ByteArrayOutputStream o = new ByteArrayOutputStream();
                    s.compress(Bitmap.CompressFormat.JPEG, 45, o);
                    cb.done(Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP), w, h);
                } catch (Exception e) { cb.done(null, 0, 0); }
            }
            @Override public void onFailure(int code) { cb.done(null, 0, 0); }
        });
    }
}
