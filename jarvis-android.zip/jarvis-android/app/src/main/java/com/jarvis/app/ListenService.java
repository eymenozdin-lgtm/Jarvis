package com.jarvis.app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import java.util.ArrayList;

// Mikrofonu sürekli dinleyen ön plan servisi: Jarvis arka plandayken de "Jarvis" demeni duyar.
public class ListenService extends Service {
    interface Sink { void on(String type, String data); }
    static volatile Sink sink;

    private SpeechRecognizer sr;
    private boolean on = false;
    private final Handler h = new Handler(Looper.getMainLooper());

    @Override public IBinder onBind(Intent i) { return null; }

    private void emit(String t, String d) { Sink s = sink; if (s != null) s.on(t, d); }

    @Override public int onStartCommand(Intent in, int flags, int id) {
        if (in != null && "STOP".equals(in.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            emit("error", "not-allowed"); stopSelf(); return START_NOT_STICKY;
        }
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("listen", "Jarvis dinleme", NotificationManager.IMPORTANCE_LOW));
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, ListenService.class).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "listen")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Jarvis dinliyor")
                .setContentText("“Jarvis” de, komutunu söyle")
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(0, "Durdur", stop).build())
                .setOngoing(true).build();
        try {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } catch (Exception e) { emit("error", "not-allowed"); stopSelf(); return START_NOT_STICKY; }
        if (!on) { on = true; listen(); }
        return START_NOT_STICKY;
    }

    private void again(long ms) { h.postDelayed(this::listen, ms); }

    private void listen() {
        if (!on) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { emit("error", "unavailable"); stopSelf(); return; }
        if (sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(this);
            sr.setRecognitionListener(new RecognitionListener() {
                @Override public void onResults(Bundle b) {
                    ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (r != null && !r.isEmpty()) emit("result", r.get(0));
                    again(200);
                }
                @Override public void onError(int e) {
                    if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { emit("error", "not-allowed"); stopSelf(); return; }
                    if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY && sr != null) sr.cancel();
                    again(e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ? 250 : 900);
                }
                @Override public void onReadyForSpeech(Bundle p) {}
                @Override public void onBeginningOfSpeech() {}
                @Override public void onRmsChanged(float v) {}
                @Override public void onBufferReceived(byte[] b) {}
                @Override public void onEndOfSpeech() {}
                @Override public void onPartialResults(Bundle b) {}
                @Override public void onEvent(int t, Bundle b) {}
            });
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        try { sr.startListening(i); } catch (Exception e) { again(1000); }
    }

    @Override public void onDestroy() {
        on = false;
        h.removeCallbacksAndMessages(null);
        if (sr != null) { sr.destroy(); sr = null; }
        super.onDestroy();
    }
}
