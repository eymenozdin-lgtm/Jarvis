package com.jarvis.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewAssetLoader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final String HOME = "https://appassets.androidplatform.net/assets/Jarvis.html";
    private WebView web;
    private PermissionRequest pending;

    private boolean has(String p) { return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED; }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        // Gerçek Android izin pencereleri: açılışta hepsini iste
        List<String> need = new ArrayList<>();
        String[] all = {Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA,
                Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
        for (String p : all) if (!has(p)) need.add(p);
        if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) need.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), 1);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();

        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setGeolocationEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new Bridge(), "JarvisNative");

        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("appassets.androidplatform.net".equals(u.getHost())) return false;
                try {
                    Intent i = "intent".equals(u.getScheme()) ? Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME) : new Intent(Intent.ACTION_VIEW, u);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Exception e) { /* açılamadı */ }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest r) {
                runOnUiThread(() -> {
                    List<String> n = new ArrayList<>();
                    for (String res : r.getResources()) {
                        if (res.equals(PermissionRequest.RESOURCE_AUDIO_CAPTURE) && !has(Manifest.permission.RECORD_AUDIO)) n.add(Manifest.permission.RECORD_AUDIO);
                        if (res.equals(PermissionRequest.RESOURCE_VIDEO_CAPTURE) && !has(Manifest.permission.CAMERA)) n.add(Manifest.permission.CAMERA);
                    }
                    if (n.isEmpty()) r.grant(r.getResources());
                    else { pending = r; requestPermissions(n.toArray(new String[0]), 2); }
                });
            }
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                cb.invoke(origin, has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION), false);
            }
        });

        web.loadUrl(HOME);
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (pending != null) {
            boolean ok = res.length > 0;
            for (int r : res) if (r != PackageManager.PERMISSION_GRANTED) ok = false;
            if (ok) pending.grant(pending.getResources()); else pending.deny();
            pending = null;
        }
    }

    // Not: onPause'da WebView durdurulmaz; kumanda başka uygulamayı açınca bağlantı sürsün diye.

    class Bridge {
        @JavascriptInterface public boolean enabled() { return ControlService.inst != null; }
        @JavascriptInterface public void openAccess() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        }
        @JavascriptInterface public void tap(float x, float y) { ControlService s = ControlService.inst; if (s != null) s.tap(x, y); }
        @JavascriptInterface public void longPress(float x, float y) { ControlService s = ControlService.inst; if (s != null) s.longPress(x, y); }
        @JavascriptInterface public void swipe(float x1, float y1, float x2, float y2, int ms) { ControlService s = ControlService.inst; if (s != null) s.swipe(x1, y1, x2, y2, ms); }
        @JavascriptInterface public void global(String k) { ControlService s = ControlService.inst; if (s != null) s.global(k); }
        @JavascriptInterface public void text(String t) { ControlService s = ControlService.inst; if (s != null) s.text(t); }
        @JavascriptInterface public void key(String k) { ControlService s = ControlService.inst; if (s != null) s.key(k); }
        @JavascriptInterface public void shot() {
            ControlService s = ControlService.inst;
            if (s == null) return;
            s.shot((b, w, h) -> runOnUiThread(() -> web.evaluateJavascript(
                    "window.__frame(" + (b == null ? "null" : "'" + b + "'") + "," + w + "," + h + ")", null)));
        }
    }
}
